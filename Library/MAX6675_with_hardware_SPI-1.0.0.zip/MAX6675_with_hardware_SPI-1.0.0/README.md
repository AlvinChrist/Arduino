# MAX6675 thermocouple interface library
## Contents
1. About the library
2. How to use
3. Author

## 1. About the library
This tiny library is intended to be used with MAX6675 thermocouple interface chip. Libraty currently supports hardware SPI only. Library keeps polling time of the MAX6675 according to the datasheet.
## 2. How to use
See included example, it's quite self-explanatory.
## 3. Author
Evgeny Kremer, evgeny.kremer@gmail.com
